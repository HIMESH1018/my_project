<?php
include 'includes/header.php';
include 'includes/nav.php';
?>
	<link rel="stylesheet" type="text/css" href="css/selectFilm.css">
	<link rel="stylesheet" type="text/css" href="css/buy.css">
	<link rel="stylesheet" type="text/css" href="css/modal.css">
	<link rel="stylesheet" type="text/css" href="css/seat.css">
	<script>
		var movie_id = <?php if(isset($_GET['id'])) echo $_GET['id']; else echo "1"; ?>;
	</script>
	<script src="js/jquery.redirect.js"></script>
	<script src="js/movie_show.js"></script>
<div>
	<div class="main-slider">
		<div class="w3-content w3-section">
		  <img class="slides" src="images/slider/robin2.jpg" style="width:100%">
		  <img class="slides" src="images/slider/hotel2.jpg" style="width:100%">
		  <img class="slides" src="images/slider/mia2.jpg" style="width:100%">
		  <img class="slides" src="images/slider/mission2.jpg" style="width:100%">
		</div>
    </div>

	<div id="show-date-outer">
		<div class="container">
			<div class="row">
				<div class="col-sm-6 text-center">
					<div id="date-container">
						<ul class="list-inline list-unstyled" id="ul_movieshow">
							<li class="datepick active">
								<div class="month-wp ng-binding">Oct</div>
								<div class="date-wp ng-binding">05</div>
								<div class="day-wp ng-binding">Fri</div>
							</li>
							<li class="datepick">
								<div class="month-wp ng-binding">Oct</div>
								<div class="date-wp ng-binding">05</div>
								<div class="day-wp ng-binding">Fri</div>
							</li>
							<li class="datepick">
								<div class="month-wp ng-binding">Oct</div>
								<div class="date-wp ng-binding">05</div>
								<div class="day-wp ng-binding">Fri</div>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<div id="show-time-table">
		<div class="container">
			<div class="row">
				<div  id="show_status" class="theater-show"></div>
				<table class="table table-responsive">
					<tbody>
						<tr class="firsttheaterrow">
							<td class="theater">
								<div class="theater-show">Show Times</div>
							</td>
							<td class="theater-showtime" colspan="5" >
								<ul id="ul_showtime">
								</ul>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>
		<!-- The Modal -->
	<div id="modal_show" class="modal">

	  <!-- Modal content -->
	  <div class="modal-content dark">
		<div class="modal-header">
		  <span class="close">&times;</span>
		</div>
		<div class="modal-body">
			<input type="hidden" id="show_time"/>
			<input type="hidden" id="show_date"/>
			<table class="tbl_modal bold">
				<tr>
					<td>
						Number of Tickets
					</td>
					<td>
						<input type="number" id="ticket_count" min=1 value="1"/>
					</td>
				</tr>
				<tr>
					<td>
					</td>
					<td>
						<button class="button" id="btn_ticketnos">Next</button>
					</td>
				</tr>
			</table>
		</div>
	  </div>
	</div>
	
	<div id="modal_seat" class="modal">

		  <!-- Modal content -->
		<div class="modal-content dark">
			<div class="modal-header">
			  <span class="close">&times;</span>
			</div>
			<div class="modal-body" style="padding-bottom:30px; padding-top:30px">
				<div id="seat_error"></div>
				<div class="center">
					<span class="seat"><div><a href="" no="A01">A01</a></div></span>
					<span class="seat"><div><a href="" no="A02">A02</a></div></span>
					<span class="seat"><div><a href="" no="A03">A03</a></div></span>
					<span class="seat"><div><a href="" no="A04">A04</a></div></span>
					<span class="seat"><div><a href="" no="A05">A05</a></div></span>
					<span class="seat"><div><a href="" no="A06">A06</a></div></span>
					<span class="seat"><div><a href="" no="A07">A07</a></div></span>
					<span class="seat"><div><a href="" no="A08">A08</a></div></span>
					<span class="seat"><div><a href="" no="A09">A09</a></div></span>
					<span class="seat"><div><a href="" no="A10">A10</a></div></span>
					<br/><br/><br/>
					<span class="seat"><div><a href="" no="B11">B11</a></div></span>
					<span class="seat"><div><a href="" no="B12">B12</a></div></span>
					<span class="seat"><div><a href="" no="B13">B13</a></div></span>
					<span class="seat"><div><a href="" no="B14">B14</a></div></span>
					<span class="seat"><div><a href="" no="B15">B15</a></div></span>
					<span class="seat"><div><a href="" no="B16">B16</a></div></span>
					<span class="seat"><div><a href="" no="B17">B17</a></div></span>
					<span class="seat"><div><a href="" no="B18">B18</a></div></span>
					<span class="seat"><div><a href="" no="B19">B19</a></div></span>
					<span class="seat"><div><a href="" no="B20">B20</a></div></span>
					<br/><br/><br/>
					<span class="seat"><div><a href="" no="C21">C21</a></div></span>
					<span class="seat"><div><a href="" no="C22">C22</a></div></span>
					<span class="seat"><div><a href="" no="C23">C23</a></div></span>
					<span class="seat"><div><a href="" no="C24">C24</a></div></span>
					<span class="seat"><div><a href="" no="C25">C25</a></div></span>
					<span class="seat"><div><a href="" no="C26">C26</a></div></span>
					<span class="seat"><div><a href="" no="C27">C27</a></div></span>
					<span class="seat"><div><a href="" no="C28">C28</a></div></span>
					<span class="seat"><div><a href="" no="C29">C29</a></div></span>
					<span class="seat"><div><a href="" no="C30">C30</a></div></span>
					<br/><br/><br/>
				</div>
				<button class="button" id="btn_seatbook">Next</button>
			</div>
		</div>
	</div>
</div>
<script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("slides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 3000); // Change image every 2 seconds
}
</script>
<?php
include 'includes/footer.php';
?>
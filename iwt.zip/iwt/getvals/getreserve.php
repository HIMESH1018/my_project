<?php
	require(dirname(__DIR__).'\conf\db_connect.php');
	
	$arrMovie = array();
	try{
		$query = "select m.name, t.date_time,count(t.ticket_no) noticket from ticket t inner join movie_show s on t.date_time = s.date_time inner join movie m on m.movie_id = s.movie_id GROUP by m.name, t.date_time";
		$rs = $conn->query($query);
		while($row = $rs->fetch_assoc()) {
			$arrMovie[] = $row;
		}
	}
	Catch(Exception $e)
	{
		echo "Failed : ".$e->getMessage();
	}
	echo json_encode($arrMovie);
	
?>
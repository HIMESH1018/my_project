<?php
	require(dirname(__DIR__).'\conf\db_connect.php');
	
	$arrSeats = array();
	if(isset($_POST['show_time']))
	{
		$show_time = $_POST['show_time'];
		$show_date = $_POST['show_date'];
		try{
			$datetime = $show_date." ".$show_time;
			$query = "select seat_no from ticket where date_time = '$datetime'";
			$rs = $conn->query($query);
			while($row = $rs->fetch_assoc()) {
				$arrSeats[] = $row;
			}
		}
		Catch(Exception $e)
		{
			echo "Failed : ".$e->getMessage();
		}
	}
	echo json_encode($arrSeats);
	
?>
<?php
	require(dirname(__DIR__).'\conf\db_connect.php');
	
	$arrMovie = array();
	try{
		$search = "";
		if(isset($_GET['search']) && $_GET['search'] == "0")
			$search = "";
		else if(isset($_GET['search']) && $_GET['search']!= null)
			$search = $_GET['search'];
		else
			$search = "";
		
		$query = "select movie_id, name, image, trailer, review from movie where removed_date is null and name like '%$search%'";
		$rs = $conn->query($query);
		while($row = $rs->fetch_assoc()) {
			$arrMovie[] = $row;
		}
	}
	Catch(Exception $e)
	{
		echo "Failed : ".$e->getMessage();
	}
	echo json_encode($arrMovie);
	
?>
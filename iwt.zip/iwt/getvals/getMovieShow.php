<?php
	require(dirname(__DIR__).'\conf\db_connect.php');
	
	$arr = array();
	$movie_id = 1;
	if(isset($_GET['movie_id']))
	{
		$movie_id = $_GET['movie_id'];
	}
	try{
		$time = "concat(\"'\",time(date_time),\"'\")";
		$query = "SELECT DATE(date_time) movie_date, monthname(date_time) movie_month, dayname(date_time) movie_week, DAYOFMONTH(date_time) movie_day, GROUP_CONCAT( $time SEPARATOR ',' ) AS movie_shows FROM movie_show WHERE movie_id = $movie_id and date_time >= CURRENT_TIME group by 1,2,3,4";
		$rs = $conn->query($query);
		while($row = $rs->fetch_assoc()) {
			$arr[] = $row;
		}
	}
	Catch(Exception $e)
	{
		echo "Failed : ".$e->getMessage();
	}
	echo json_encode($arr);
	
?>
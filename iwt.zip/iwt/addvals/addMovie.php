<?php
	require(dirname(__DIR__).'\conf\db_connect.php');
	session_start();
	$arr = array();
	$arr['status'] = false;
	$name = "";
	$trailer = "";
	$review = "";
	$emp_id = $_SESSION['user_id'];
	if(isset($_POST['name']))
	{
		$name = $_POST['name'];
		$trailer = $_POST['trailer'];
		$review = $_POST['review'];
		try{
			if(isset($_FILES["image"]["name"]))
			{
				$sourcePath = $_FILES['image']['tmp_name'];
				$targetPath = dirname(__DIR__)."\images\\uploads\\".$_FILES['image']['name'];
				move_uploaded_file($sourcePath,$targetPath);
			
				$img = fopen($targetPath, 'r') or die("cannot read image\n");
				$data = fread($img, filesize($targetPath));
				
				$destpath = "images/uploads/".$_FILES['image']['name'];
				
				$query = "insert into movie (name, added_date,emp_id,image,trailer,review) values('$name',curdate(),$emp_id,'$destpath','$trailer','$review')";
				
				if($conn->query($query))
				{
					$arr['status'] = true;
				}
			}
		}
		Catch(Exception $e)
		{
			echo "Failed : ".$e->getMessage();
		}
	}
	echo json_encode($arr);
	
?>
<?php
	require(dirname(__DIR__).'\conf\db_connect.php');
	session_start();
	$arr = array();
	$arr['status'] = false;
	$arr['message'] = "Error Occurred";
	$movie_id = "";
	$name = "";
	$trailer = "";
	$review = "";
	$status = "update";
	$emp_id = $_SESSION['user_id'];
	if(isset($_POST['name']))
	{
		$movie_id = $_POST['movie_id'];
		$name = $_POST['name'];
		$trailer = $_POST['trailer'];
		$review = $_POST['review'];
		$status = $_POST['status'];
		try{
			if($status == "update")
			{
				if(isset($_FILES["image"]["name"]))
				{
					$sourcePath = $_FILES['image']['tmp_name'];
					$targetPath = dirname(__DIR__)."\images\\uploads\\".$_FILES['image']['name'];
					move_uploaded_file($sourcePath,$targetPath);
				
					$img = fopen($targetPath, 'r') or die("cannot read image\n");
					$data = fread($img, filesize($targetPath));
					
					$destpath = "images/uploads/".$_FILES['image']['name'];
					
					$query = "update movie set name='$name',image = '$destpath', trailer='$trailer',review='$review' where movie_id = $movie_id";
					if($conn->query($query))
					{
						$arr['status'] = true;
						$arr['message'] = "Movie Updated Successfully";
					}
				}
				else
				{
					$query = "update movie set name='$name', trailer='$trailer',review='$review' where movie_id = $movie_id";
					if($conn->query($query))
					{
						$arr['status'] = true;
						$arr['message'] = "Movie Updated Successfully";
					}
				}
			}
			else if($status == "delete")
			{
				$query = "update movie set removed_date=curdate() where movie_id = $movie_id";
				if($conn->query($query))
				{
					$arr['status'] = true;
					$arr['message'] = "Movie Deleted Successfully";
				}
			}
		}
		Catch(Exception $e)
		{
			echo "Failed : ".$e->getMessage();
		}
	}
	echo json_encode($arr);
	
?>
<?php
	require(dirname(__DIR__).'\conf\db_connect.php');
	session_start();
	$arr = array();
	$arr['status'] = false;
	$price = 400;
	$cust_id =  $_SESSION['user_id'];
	$seats = 0;
	$show_time = "";
	$show_date = "";
	$seat_nos = array();
	if(isset($_POST['seats']))
	{
		$seats = $_POST['seats'];
		$show_time = $_POST['show_time'];
		$show_date = $_POST['show_date'];
		$seat_nos = $_POST['seat_nos'];
		$date_time = $show_date." ".$show_time;
		try{
			$query1 = "insert into payment(amount,pdate,cus_id) values($seats * 400,curdate(),1)";
			$quer1_id = "SELECT LAST_INSERT_ID() pay_id;";
			
			
			if($conn->query($query1) && $rs = $conn->query($quer1_id))
			{
				if($row = $rs->fetch_assoc())
				{
					$pay_id = $row['pay_id'];
					$arr['tickets'] = array();
					for($i=0; $i<count($seat_nos); $i++)
					{
						$query2 = "insert into ticket(price,date,cus_id,emp_id,seat_no,date_time,pay_id) values($price,curdate(),$cust_id,1,'$seat_nos[$i]','$date_time',$pay_id)";
						$query2_id = "SELECT LAST_INSERT_ID() ticket_id, '$seat_nos[$i]' seat_no;";
						if($conn->query($query2) && $rs2 = $conn->query($query2_id))
						{
							if($row2 = $rs2->fetch_assoc())
							{
								$arr['tickets'][] = $row2;
							}
						}
						else
						{
							$arr['status'] = false;
							break;
						}
					}
					$arr['status'] = true;
				}				
			}
		}
		Catch(Exception $e)
		{
			echo "Failed : ".$e->getMessage();
		}
	}
	echo json_encode($arr);
	
?>
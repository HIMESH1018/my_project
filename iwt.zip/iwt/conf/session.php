<?php
	session_start();
	if(isset($_SESSION['logged_in']) && $_SESSION['logged_in'])
	{
		$logged_in = $_SESSION['logged_in'];
		$user_id = $_SESSION['user_id'];
		$user = $_SESSION['user'];
		$email = $_SESSION['email'];
		$type = $_SESSION['type'];
	}
	else
	{
		$logged_in = false;
		if(basename($_SERVER['PHP_SELF']) != "movie.php" && basename($_SERVER['PHP_SELF']) != "index.php")
			header("Location: login.php");
	}
?>